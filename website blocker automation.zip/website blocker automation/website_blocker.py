import time
from datetime import datetime as dt

#Taking the hosts for different platforms
linux_host = '/etc/hosts' #for ubuntu
macos_host = '/private/etc/hosts'
windows_host = "c:\windows\system32\drivers\etc\hosts"

redirect = "127.0.0.1"

#Taking the default host accordingly

default_host = linux_host

#list the website to be block

website_to_block = ["www.facebook.com","facebook.com","fblogin","youtube","youtube.com","www.youtube.com","www.instagram.com","instagram.com","iglogin",]

while True:
  if dt(dt.now().year,dt.now().month,dt.now().day,7) < dt.now() < dt(dt.now().year,dt.now().month,dt.now().day,18):
    with open(default_host,"r+") as file:
     content = file.read()
    for website in website_to_block:
        if website in content:
          pass
        else:
         file.write(redirect+ " " +website+ "\n")
    print("All websites are blocked!")
    break
  else:
    with open(default_host,"r+") as file:
     content = file.readlines()
     file.seek(0)
     for line in content:
        if not any (website in line for website in website_to_block):
          file.write(line)
     file.trucate()
    print("All websites are unblocked")
    break   
 
